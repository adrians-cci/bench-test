def getAlarmSummary(filterPath='*'):
	global myAlarms
	myAlarms = system.alarm.queryStatus(priority=[1,2,3,4])