import re		
def onTagDrop(paths):
	"""Add pen to easy chart on tag drop action
	
	Args:
		paths: list of dropped tag paths
	Returns:
		list of lists containing {selectedPath, tagPath, tagProvider, 3}
	"""
	searchString = r'\[(.*?[^0-9])\]'
	pensToAdd = list()
	for selectedPath in paths:
		parseString = re.split(searchString, selectedPath.strip())
		parseString = parseString[1:] if parseString[0] == '' else parseString
			
		tagPath = parseString[-1]
		tagProvider = parseString[0].split('/')[-1].split(':')[-1] if len(parseString) > 1 else 'default'
		item = (selectedPath, tagPath, tagProvider, 3)
		print "Selected Path: {}, Tag Path: {}, Tag Provider: {}".format(*item)
		pensToAdd.append(item)
	return pensToAdd
