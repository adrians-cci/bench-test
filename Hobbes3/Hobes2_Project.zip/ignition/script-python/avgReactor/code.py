def avgMeasurement(i_r1_meas,i_r1_meas_disabled,i_r2_meas,i_r2_meas_disabled,i_r3_meas,i_r3_meas_disabled,i_r4_meas,i_r4_meas_disabled) :
	data = { i_r1_meas : i_r1_meas_disabled,
			 i_r2_meas : i_r2_meas_disabled,
			 i_r3_meas : i_r3_meas_disabled,
			 i_r4_meas : i_r4_meas_disabled
			}
	meas_sum = 0
	meas_count = 0
	average = 0
	for meas,is_disabled in data.items():
		if not is_disabled: 
			meas_sum = meas_sum + meas
			meas_count = meas_count + 1
	if meas_count > 0 :
		average = meas_sum/meas_count
	return average